/**
 * Can Ngo
 * Account.java
 * ITSC 1213 Homework 3
 *
 */
import java.util.*;

public class Account {
    
    
    private int accountSSN;
    private static ArrayList listOfAllId = new ArrayList<>();
    private double balance = 0;
    
    private String billingAddress;
    private int accountRouting;  //9 digit random number
    private int accountChecking; //9 digit random number
    
    //every ID we create will added to the list
    public static void addIdNum(int a){
    listOfAllId.add(a);
    }
    public Account(int a, String b, double c){
    
    accountSSN = a;
    billingAddress = b.toUpperCase();
    balance = c; //initial deposit on the account
    accountRouting = generateNineDigitNumber();
    accountChecking = generateNineDigitNumber();
    
    
    }
    
    public Account(){
    }

    public void setAccountRouting(int accountRouting) {
        this.accountRouting = accountRouting;
    }

    public void setAccountChecking(int accountChecking) {
        this.accountChecking = accountChecking;
    }
    
    
    public void setBalance(double balance){
    this.balance = balance;
    }
    
    public void setAccountSSN(int accountSSN) {
        this.accountSSN = accountSSN;
    }

    public void setBillingAddress(String billingAddress) {
        this.billingAddress = billingAddress;
    }
    /**
     * This method is extremely important because it prevents  repeated account # and repeated routing #
     */
    public static int generateNineDigitNumber(){
        int number = 0;
        int x = 0;
        while(x == 0){
         number = (int)((Math.random()*(999999999-100000000))+(100000000));
         if(listOfAllId.size() == 0){
             number = number;
             listOfAllId.add(number);
             x = 1;
         }else{
             for(int i = 0; i < listOfAllId.size(); i++){
                 int currentNum = (int)listOfAllId.get(i);
                 if(i == listOfAllId.size() - 1 && number != currentNum){
                     number = number;
                     listOfAllId.add(number);
                     x = 1;
                 }
             }
             
         }
        }
       return number;
    }
   

    
    
    public int getAccountSSN() {
        return accountSSN;
    }

    public String getBillingAddress() {
        return billingAddress.toUpperCase();
    }

    public int getAccountRouting() {
        return accountRouting;
    }

    public int getAccountChecking() {
        return accountChecking;
    }
    
    public double getBalance(){
        return balance;
    }

    public void addTransaction(){
    
    }
    public void withdraw(double balance){
    this.balance = this.balance - balance;  
    
    }
    
    public void deposit(double balance){
    this.balance = this.balance + balance;  
    
    }
       
    
  
    
}


