

import java.util.*;
import javax.swing.*;

/**
 *
 * @author Can Ngo
 * Bank.java
 * ITSC 1213 Homework 3: Create all methods, fields, and classes for my program
 * 
 * Please note that my method stubs are basically my major functions. They will be complete when I set up the GUi for my project.
 * 
 * ANOTHER IMPORTANT NOTE: I should have probably created a stand-alone method for sorting and matching but it was already too late.
 * 
 * THE MAIN METHOD HAS BEEN REMOVED.
 * 
 * MAJOR FUNCTIONS: The 5 BUTTON are the major functions. THE JTEXTAREA IS NOT A MAJOR FUNCTION.
 * 
 */
public class Bank {
  
    private static ArrayList allAccounts = new ArrayList<Account>();
    
    public Bank(){
        //we will add a dummy bank account. This is needed to ensure that the for loops go through, i.e, if we allAccounts.size() == 0, then the loops will
        //not run because i < allAccounts.size() is FALSE. However, allAccounts.size() can be at least 1 or more.
        //This is taking into consideration that we will be calling a STATIC bank when in the MainMenu JFrame.
        addAccount(new Account(0,"0",0));
    }
    
    public static ArrayList getAllAccounts(){
   
    return allAccounts;

    }
    
    
  /**
   * MAJOR FUNCTION - Adding a transaction. The user will be able to input their SSN, account and checking number. Additionally, the program will
   * ask the user for a deposit or a withdraw at first.
   */
   public static void addTransaction(){
       boolean deposit = false;

    while(true){
          
     int userEntry = Integer.parseInt(JOptionPane.showInputDialog(null,"Is this going to be a deposit or a withdraw? Type '1' for deposit, type '2' for withdraw. Type '-1' to cancel.", "Add Transaction",JOptionPane.INFORMATION_MESSAGE));
       if(userEntry == 1){
           deposit = true;
           break;
       }else if(userEntry == 0){
           deposit = false;
           break;
       }else if(userEntry == -1){
           JOptionPane.showMessageDialog(null, "Operation Cancelling. User put in '-1'");
           return;
       }else{
           JOptionPane.showMessageDialog(null, "You did not specify a deposit or withdraw. Type -1 if you want to cancel.");
       }
       
       }
       
        int userCheckingNum = 0;
        int userRoutingNum = 0;
        int userSSN = 0;
        
        
        while(true){
            
            int userCheckingEntry = Integer.parseInt(JOptionPane.showInputDialog("Enter your 9 digit CHECKING/ACCOUNT number. Type '-1' to cancel: "));
            int userRoutingEntry = Integer.parseInt(JOptionPane.showInputDialog("Enter your 9 digit ROUTING number. Type '-1' to cancel: "));
            int userSSNEntry = Integer.parseInt(JOptionPane.showInputDialog("Enter your 9 digit SSN Number for added security. Type '-1' to cancel"));
            if(userCheckingEntry == -1 || userRoutingEntry == -1 || userSSNEntry == -1){
                JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
                return;
            }
            
            String userCheckingEntryCheck = "" + userCheckingEntry;
            String userRoutingEntryCheck = "" + userRoutingEntry;
            String userSSNEntryCheck = "" + userSSNEntry;
            
            if(userCheckingEntryCheck.length() == 9 && userRoutingEntryCheck.length() == 9 && userSSNEntryCheck.length() == 9){
                userCheckingNum = userCheckingEntry;
                userRoutingNum = userRoutingEntry;
                userSSN = userSSNEntry;
                break;
            }else{
                JOptionPane.showMessageDialog(null, "PLEASE ENTER A VALID CHECKING AND ROUTING NUMBER. TYPE '-1' TO CANCEL AND RETURN");
            }
            
        }
        
        for(int i = 0; i < allAccounts.size(); i++){
            Account currentAccount = (Account)allAccounts.get(i);
            if( currentAccount.getAccountChecking() == userCheckingNum && currentAccount.getAccountRouting() == userRoutingNum && currentAccount.getAccountSSN() == userSSN) {
                if(deposit){
                    double transactionAmount = Double.parseDouble(JOptionPane.showInputDialog("Please input the amount of money you want to DEPOSIT. Type '-1' to cancel. "));
                      if(transactionAmount == -1){
                          return;
                      }else if(transactionAmount <= 0){
                         JOptionPane.showMessageDialog(null,"Wrong information was entered. Please input a POSITIVE value.");
                         while(true){
                             break;
                         }
                      }else{
                          currentAccount.deposit(transactionAmount);
                           JOptionPane.showMessageDialog(null,"ACCOUNT HAS BEEN UPDATED. Your new balance is: " + currentAccount.getBalance());
                      }
                }else{
                    double transactionAmount = Double.parseDouble(JOptionPane.showInputDialog("Please input the amount of money you want to WITHDRAW. Type '-1' to cancel. "));
                    if(transactionAmount == -1){
                        return;
                    }else if(transactionAmount <= 0){
                         JOptionPane.showMessageDialog(null,"Wrong information was entered. Please input a POSITIVE value.");
                         while(true){
                             break;
                         }
                      }else{
                          currentAccount.withdraw(transactionAmount);
                           JOptionPane.showMessageDialog(null,"ACCOUNT HAS BEEN UPDATED. Your new balance is: " + currentAccount.getBalance());
                      }
                }
                
            }else if(i == allAccounts.size() - 1){
                JOptionPane.showMessageDialog(null,"Information was unable to be matched. Make sure your entries are matched with your account.");
            }
        
        }
      
   }
    /**
     * Method that just adds some account to the list.
     *
     */
    public static void addAccount(Account a){
    allAccounts.add(a);
    }
    
    public static int displayMenu(){
    
    int userChoice = Integer.parseInt(JOptionPane.showInputDialog(null,"1. Display information for an account: \n"
            + " 2. Create an account \n"
            + " 3. Delete an account \n"
            + " 4. Change information \n"
            + " 5. Add a transaction to an account \n"
            + " 6. Exit \n"
            + "Please select an option based on user input"));
              return userChoice;
    }
    
    
  
    //createAccount method that will be used in one of the major functions
    public static void createAccount(){
        int userSSN = 0;
             while(true){
                 userSSN = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter in a 9 digit SSN. Type -1 to exit: ","Create Account", JOptionPane.INFORMATION_MESSAGE));
                 if(userSSN == -1){
                    JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
                     return;
              }else{
               String userSSNString = "" + userSSN;
               if(userSSNString.length() == 9){
                       break;
               }else{JOptionPane.showMessageDialog(null ,"INVALID SSN. MAKE SURE IT IS 9 DIGITS LONG");}
         
            } 
    
        }
             
        //checks if the account already exists
        for(int i = 0; i < allAccounts.size(); i++){
            Account currentAccount = (Account)allAccounts.get(i);
            if(currentAccount.getAccountSSN() == userSSN){
            JOptionPane.showMessageDialog(null, userSSN + " Already exists");
            return;
            }else if(i == allAccounts.size() - 1){
                continue;
            }
        
        }
        
       String address =  JOptionPane.showInputDialog("Enter in the billing address. Type '-1' to cancel: ");
       if(address.equals("-1")){
           
           JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
           return;
       }
       
       double initialDeposit = Double.parseDouble(JOptionPane.showInputDialog("Enter your initial deposit. We recommend NOT depositing money yet to ensure you are able to log into your account. Type '-1' to cancel: "));
       if(initialDeposit == -1){
           JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
           return;
       }
       Account someAccount = new Account(userSSN, address, initialDeposit);
       allAccounts.add(someAccount);
       JOptionPane.showMessageDialog(null, "Account has been created. Here is your information: \n"
               + " Checking " + someAccount.getAccountChecking() + "\n"
                       + " Routing: " + someAccount.getAccountRouting());
       
    
    }
    /**
     * MAJOR FUNCTION - Display the account information. The program will ask the user for the SSN. Assuming in the real world that everyone
     * has a unique SSN, the searching should have no problem. After finding a match withing the allAccounts array list, the program will
     * display the account #, routing #, the balance, and the address associated with the account.
     */
    public static void displayInformation(){
     int userSSN = 99;
      while(true){
         int userEntry = Integer.parseInt(JOptionPane.showInputDialog(null,"Please enter the 9 digit SSN on the account. Type '-1' to cancel: ","Display Information", JOptionPane.INFORMATION_MESSAGE));
         
         if(userEntry == -1){
             JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
             return;
         }
        
        String entryCheck = "" + userEntry;
         if(entryCheck.length() == 9){
                userSSN = userEntry;
                break;
          }else{
              JOptionPane.showMessageDialog(null, "You entered an invalid SSN. It must be 9 digits, no spaces!");
          }
       }
      
      for(int i = 0; i < allAccounts.size();i++){
          Account currentAccount = (Account)allAccounts.get(i);
            if(userSSN == currentAccount.getAccountSSN()){
                JOptionPane.showMessageDialog(null, 
                       "Account SSN: " + currentAccount.getAccountSSN() + "\n"
                        + " Account Checking # " + currentAccount.getAccountChecking() + "\n"
                           + " Account Routing #: " + currentAccount.getAccountRouting() + "\n"
                              + " Account Balance: " + currentAccount.getBalance() + " \n"
                                 + "Billing Address: " + currentAccount.getBillingAddress());  
                                      break;
            }else if(i == allAccounts.size()-1){
                JOptionPane.showMessageDialog(null, "Could not find account. Please make sure you entered it correctly, or change inforamtion if needed.");
            }
      }
    }
    /**
     * MAJOR FUNCTION - Change information. The program will obtain the user's checking and routing number. When there is a match,
     * the program will allow the user to change the SSN and street address if they choose to.
     */
    public static void changeInformation(){
        
        int userCheckingNum = 0;
        int userRoutingNum = 0;
        
        
        while(true){
            
            int userCheckingEntry = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter your 9 digit CHECKING/ACCOUNT number. Type '-1' to cancel: ","Change Information", JOptionPane.INFORMATION_MESSAGE));
             if(userCheckingEntry == -1){
                JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
                return;
            }
            
            
            int userRoutingEntry = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter your 9 digit ROUTING number. Type '-1' to cancel: ","Change Information", JOptionPane.INFORMATION_MESSAGE));
            
            if(userRoutingEntry == -1){
                JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
                return;
            }
            
            String userCheckingEntryCheck = "" + userCheckingEntry;
            String userRoutingEntryCheck = "" + userRoutingEntry;
            
            if(userCheckingEntryCheck.length() == 9 && userRoutingEntryCheck.length() == 9){
                userCheckingNum = userCheckingEntry;
                userRoutingNum = userRoutingEntry;
                break;
            }else{
                JOptionPane.showMessageDialog(null, "PLEASE ENTER A VALID CHECKING AND ROUTING NUMBER. TYPE '-1' TO CANCEL AND RETURN");
            }
            
        }
        
        for(int i = 0; i < allAccounts.size(); i++){
            Account currentAccount = (Account)allAccounts.get(i);
            if(currentAccount.getAccountChecking() == userCheckingNum && currentAccount.getAccountRouting() == userRoutingNum){
                int changeSSN = 0;
                while(true){
                changeSSN = Integer.parseInt(JOptionPane.showInputDialog("Please enter the SSN you want to change. If you want to keep it the same, then type the same SSN. Type '-1' to cancel.: "));
                    if(changeSSN == -1){
                        JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
                        return;
                    }else if(changeSSN > 999999999 && changeSSN < 100000000){
                        JOptionPane.showMessageDialog(null, "Invalid Entry. Please enter a SSN.");
                    }
                String ssnCheck = "" + changeSSN;
                    if(ssnCheck.length() == 9){
                            changeSSN = changeSSN;
                            break;
                        }
                        
                    }
                
                String streetAddressUpdate = JOptionPane.showInputDialog("Please enter the street address you want to change. If you do not want to change the address, then type in your current address. Type '-1' to cancel. ");
                if(streetAddressUpdate.equals("-1")){
                    JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
                    return;
                }else{
                    currentAccount.setBillingAddress(streetAddressUpdate);
                    currentAccount.setAccountSSN(changeSSN);
                    
                    JOptionPane.showMessageDialog(null," Your account has been changed successfully. Updated information is: \n"
                            + " Checking # :" + currentAccount.getAccountChecking() + " \n"
                                    + " Routing # " + currentAccount.getAccountRouting() + " \n"
                                            + " Account SSN: " + currentAccount.getAccountSSN() + " \n"
                                                    + " Account Billing Address: " + currentAccount.getBillingAddress());
                }
                
            }else if(i == allAccounts.size() - 1){
                JOptionPane.showMessageDialog(null, "The information you entered does not match.");
            }
                
        }
        
        
    
    }
    /**
     * MAJOR FUNCTION - DELETE ACCOUNT. The program will ask the user for 3 things: checking, routing, and SSN(for extra security). The user will
     * be prompted with options to delete the account or cancel the operation.
     */
    public static void deleteAccount(){
        int userCheckingNum = 0;
        int userRoutingNum = 0;
        int userSSN = 0;
        
        
        while(true){
            
            int userCheckingEntry = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter your 9 digit CHECKING/ACCOUNT number. Type '-1' to cancel: ","Delete Account", JOptionPane.INFORMATION_MESSAGE));
            if(userCheckingEntry == -1){
                JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
                return;}
            
            int userRoutingEntry = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter your 9 digit ROUTING number. Type '-1' to cancel: ","Delete Account", JOptionPane.INFORMATION_MESSAGE));
            if(userRoutingEntry == -1){
                JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
                return;}
            
            int userSSNEntry = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter your 9 digit SSN Number for added security. Type '-1' to cancel","Delete Account", JOptionPane.INFORMATION_MESSAGE));
            if(userSSNEntry == -1){
                JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
                return;}
            
            if(userCheckingEntry == -1 || userRoutingEntry == -1 || userSSNEntry == -1){
                JOptionPane.showMessageDialog(null, "-1 Inputted, Cancelling Operation. Will return to main menu.");
                return;
            }
            
            String userCheckingEntryCheck = "" + userCheckingEntry;
            String userRoutingEntryCheck = "" + userRoutingEntry;
            String userSSNEntryCheck = "" + userSSNEntry;
            
            if(userCheckingEntryCheck.length() == 9 && userRoutingEntryCheck.length() == 9 && userSSNEntryCheck.length() == 9){
                userCheckingNum = userCheckingEntry;
                userRoutingNum = userRoutingEntry;
                userSSN = userSSNEntry;
                break;
            }else{
                JOptionPane.showMessageDialog(null, "PLEASE ENTER A VALID CHECKING AND ROUTING NUMBER. TYPE '-1' TO CANCEL AND RETURN");
            }
            
        }
        
        for(int i = 0; i < allAccounts.size(); i++){
            Account currentAccount = (Account)allAccounts.get(i);
            if( currentAccount.getAccountChecking() == userCheckingNum && currentAccount.getAccountRouting() == userRoutingNum && currentAccount.getAccountSSN() == userSSN) {
                int index = i;
                int userChoice = Integer.parseInt(JOptionPane.showInputDialog("ACCOUNT HAS BEEN MATCHED. ARE YOU SURE YOU WANT TO DELETE? Typ '1' to delete. Type '0' to CANCEL"));
                if(userChoice == 1){
                    int userChoice2 = Integer.parseInt(JOptionPane.showInputDialog("Are you sure? Type '1' to PERMANANTLY DELETE. Type '0' to Cancel"));
                        if(userChoice2 == 1){
                            JOptionPane.showMessageDialog(null,"Account with SSN has been deleted: " + currentAccount.getAccountSSN());
                            allAccounts.remove(index);
                        }else if(userChoice2 == 0){
                            JOptionPane.showMessageDialog(null,"Operation Cancelled.");
                            return;
                        }else{
                             JOptionPane.showMessageDialog(null,"Operation Cancelled. Value '1' not inputted.");
                            return;
                        }
                    
                }else{
                    JOptionPane.showMessageDialog(null,"Operation Cancelled. Value '1' not inputted.");
                            return;
                }
                
            }else if(i == allAccounts.size() - 1){
            
                 JOptionPane.showMessageDialog(null,"Operation Cancelled. Account can not be matched.");
                    return;
            }   
        }
    }
    
}

